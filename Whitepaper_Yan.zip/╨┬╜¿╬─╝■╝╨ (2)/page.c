#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>


//log txt
// assuming all data file start with V0, end with Vmax
int lastv(char* name){
int last = 0;
char lastl[256];
FILE *fd;
 
// go find last line of file
  if((fd = fopen(name, "r")) != NULL){
    fseek(fd, 0, SEEK_SET);
    while(!feof(fd)){
      memset(lastl, 0x00, 256);
      fscanf(fd, "%[^\n]\n", lastl);
    }
  }
  else{printf("can not open this file");return;}
  
  // get the last v# from last line in file
  sscanf(lastl, "%d", &last);
  fclose(fd);
  return last;
}


// return the 2d array of graph
// better way will be linked list keep the egdes, this will log
// graph faster and need less space
int** load_graph(char* name, int last){ 
  int vertix;
  int edge;
  int row = 0;
  int colunm = 1;
  // load last line, get last n
  FILE *fp;
  char line[256];
  
  int  vertices [last][last];
  // I use -1 denote no link from this node to another
  for(int i =0; i<= last; i = i+1){
    for(int j =0; j<= last; j = j+1){
      vertices[i][j] = -1;
    }
  }
  

  
  //---start log file
  fp = fopen(name, "r");
  // read file line by line
  while(fgets(line,sizeof(256), fp) != NULL){
    // check if current line is start with vertex in graph
    if(isdigit(line[0])){
      sscanf(line, "%d %d", &vertix,&edge);
      // reset [][] postion if change vertice
      if(row != vertix){
	row = vertix;
	colunm = 1;
      }
      
      vertices[vertix][colunm] = edge;
      colunm = colunm +1;
    }
  }
  fclose(fp);
  return vertices;
}


// random walk  use probability 1-D[0,1]//
// 1-D = 1/d(u)[neighbors], D = any node
// return 1 = head(1/n), 2 = tail(1/du)
int random_D(double D){
  double coin = (double) rand() / RAND_MAX;
  if(coin <= D){return 1;}
  return 2;
}



// for every node, random walk it, track # times every node visited,
// #n1 / K*n = rank for each node


//------main program------
int main(int argc, char *argv[]){
  //input
  FILE *fp;
  char filename[256];
  int last = 0;
  int count = 0;
  int i;
  int j;
  
    if(argc < 3){
      printf("need input K(length of random walk) and D(damping ratio)\n");
      exit(1);
    }

  int K = atoi(argv[1]);
  int D = atoi(argv[2]);

  // find time for log the data 
  double timel = omp_get_wtime();
  
  // read graph data
  printf("type the file location to read graph file: \n");
  fgets(filename, sizeof(filename), stdin);

  
  //log graph call
  last = lastv(filename);
  //int vertices [last][last];
  int **vertices = load_graph(filename, last);

  
  // find how many links for each node
  int element_count[last];
  
  for( i =0; i<= last; i = i+1){
    for( j =1; j<= last; j = j+1){ 
      if(vertices[i][j] == -1){
	break;
      }
      count = count +1;
    }
    element_count[i] = count;
    count = 0;
  }
  //
  timel = omp_get_wtime() - timel;


  
  int p = 64; // set 64 threads now.
  omp_set_num_threads(p);



#pragma omp parallel
  {
    //check if able to get p threads
    // pass
    assert(p==omp_get_num_threads());
    //printf("number of threads set = %d\n", omp_get_num_threads());
    
    int rank = omp_get_thread_num();
    //printf("Rank = %d; iterations(n) = %d ;threads(p) = %d \n", rank, n, p);
  }


  i = 0;
  j = 0;
  int x;    // x is the current mark that denote what node I am on now
  int coin;
  int vlist [last];  // tracker

  // list for track nodes rank
  for(i= 0; i<= last; i = i+1){
    vlist[i] = 0;
  }

  // time for parallel alg
  double timep = omp_get_wtime();
  
#pragma omp parallel for default(shared) private(i,j,x,coin) reduction(+: vlist)        

  
  
  // strat for every node
  for(i = 0; i< last; i = i+1){
    for(j = 0; j < K; j=j+1){//do K walks
      vlist[i] = vlist[i]+1;
      
      // head or tail
      coin = random_D(D);
      if(coin == 1){// head -> go random node
	double r =  (double) rand() / RAND_MAX;
	x = r * last;
      }
      else{// go 1/du +1 node
	double r =  (double) rand() / RAND_MAX;
	// rand value from [0,1] * # of nodes that connect to this node
	int visit_index = r *  element_count[x];
	x = vertices[0][visit_index];
      }
      vlist[x] = vlist[x] +1;
    }
  }

  timep = omp_get_wtime() - timep;
  printf("parallel run time = %.5f s \n", timep);
  printf("graph log time = %.5f s \n", timel);

  //find top 5 in tracker list
  printf("The 5 top ranked page is: \n");
 
  /* sort and print
  for(i = 0; i < 5; i = i+1){
    printf("node: %d", vlist[i]);
  }
  */
}
